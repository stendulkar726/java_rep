package com.cg.lession14.demo;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

public class TestSum {
	Sum s = new Sum();


	@Test
	public void test() {
		assertEquals(30, s.add(10, 20));
		assertNotEquals(200, s.add(10, 20));
		
	}
	
	@Test(expected = ArithmeticException.class)
	public void testDiv() {
		assertEquals(2, s.div(20, 10));
		assertNotEquals(69, s.div(30, 0));
		
	}
	
	@Test(timeout = 1)
	public void testTime()
	{
		for (long i = 0; i < 100000000; i++) {
			
		}
	}
}
