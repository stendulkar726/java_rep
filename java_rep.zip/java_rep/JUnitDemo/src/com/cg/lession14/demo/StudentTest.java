package com.cg.lession14.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StudentTest {

	@Test
	public void testGetRollNo() {
		Student s = new Student(100, "Sam" , "Dcosta");
		assertEquals(s.getRollNo(), 100);
	}
	
	@Test
	public void testGetFirstName() {
		Student s = new Student(100, "Sam" , "Dcosta");
		assertEquals(s.getFirstName(), "Sam");
		
	}
	
	@Test
	public void testGetLastName() {
		Student s = new Student(100, "Sam" , "Dcosta");
		assertEquals(s.getLastName(), "Dcosta");
		
	}


}
