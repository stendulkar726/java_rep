package com.cg.lession14.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PersonTest {
	Person p = new Person("Tony", "Stark");

	@Test
	public void testNotNullsInName() {
		System.out.println("testnotnullinname");
//		assertNotNull(p.getFullname());
		assertNotNull(p.getFirstname());
		assertNotNull(p.getLastname());
		
	}
	@Test
	public void testNullInName() {
		System.out.println("Check Null in names");
		Person p1 = new Person(null, "Abhimanyu");
		assertNull(p1.getFirstname());
		Person p2 = new Person("Dwivedi" , null);
		assertNull(p2.getLastname());
		
	}
	@Test(expected = IllegalStateException.class)
	public void testNullsInName() {
		System.out.println("from testing exceptions");
		Person per1 = new Person(null, null);
	}

}
