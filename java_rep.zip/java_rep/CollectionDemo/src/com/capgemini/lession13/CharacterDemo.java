package com.capgemini.lession13;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharacterDemo {
	public static void main(String[] args) {
		String str = "This is Capgemini";
		String str_irish = "is é seo capgemini";
		String str_sindhi = "هي ڪيپيمييني آهي";
		String str_krrygzy = "Бул capgemini болуп саналат";
		String str_zulu = "le yi-capgemini";
		
		File f = new File("mydir" , "mytxt.txt");
		try {
			FileWriter fw = new FileWriter(f);
			fw.write(str);
			fw.write(str_irish);
			fw.write(str_sindhi);
			fw.write(str_krrygzy);
			fw.write(str_zulu);
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try {
			FileReader fr = new FileReader(f);
			int s = (int) f.length();
			char[] ch = new char[s];
			fr.read(ch);
			for (char c : ch) {
				System.out.println(c);
			}
			fr.close();
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
