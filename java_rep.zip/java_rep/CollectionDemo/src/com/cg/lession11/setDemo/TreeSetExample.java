package com.cg.lession11.setDemo;
import java.util.HashSet;
import java.util.Set;

 

public class TreeSetExample {
	public static void main(String[] args) {

		Emp e1=new Emp(1005,"Abhimanyu",4000000.00);

		Emp e2=new Emp(1006,"Dwivedi",4400000.00);

		Set<Emp> hs=new HashSet<Emp>();
		hs.add(e1);
		hs.add(e2);
		System.out.println(hs);
	}
}
