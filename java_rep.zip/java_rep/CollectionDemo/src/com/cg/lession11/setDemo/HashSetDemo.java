package com.cg.lession11.setDemo;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class HashSetDemo {
 public static void main(String[] args) {
	boolean f = false;
	Set<String> hs = new HashSet<String>();
	Scanner sc = new Scanner(System.in);
	for (int i = 0; i < 5; i++) {
		String st = sc.next();
		f = hs.add(st);
		if(f) {
			System.out.println("added");
		}
		else
		{
			System.out.println("Duplicate");
		}
		
		System.out.println(hs);
	}
}
}
