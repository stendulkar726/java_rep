package com.cg.lession11.setDemo;

import java.util.NavigableSet;
import java.util.TreeSet;

public class SortedSetDemo {

	public static void main(String[] args) {
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("banana");
		ts.add("lemon");
		ts.add("orange");
		System.out.println(ts);
		
		
		NavigableSet<String> ns1 = ts.descendingSet();
		System.out.println(ns1);
		
		NavigableSet<String> ns2 = ts.headSet("banana", true);
		System.out.println(ns2);
		ns2.add("apricot");
		System.out.println(ns2);
		ns2.add("apple");
		System.out.println(ns2);
		
	}

}
