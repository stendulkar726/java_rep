package com.cg.lession11.setDemo;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class LinkedHashSetDemo {
	public static void main(String[] args) {
		boolean f = false;
		Set<String> hs = new LinkedHashSet<String>();
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			String st = sc.next();
			f = hs.add(st);
			if(f) {
				System.out.println("added");
			}
			else
			{
				System.out.println("Duplicate");
			}
			
			System.out.println(hs);
		}
	}

}
