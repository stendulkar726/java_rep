package com.cg.lession11.map;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
	public static void main(String[] args) {
//		---------------------MAP 1 ---------------------------
		
		Map<String, String> map1 = new HashMap<String, String>();
		map1.put("one", "1");
		map1.put("two", "2");
		map1.put("three", "3");
		map1.put("four", "4");
		map1.put("five", "5");
		map1.put("six", "6");
		System.out.println("MAP1 :-->" + map1);
		
		
//		-------------------------MAP 2 --------------------------
		
		Map<String, String> map2 = new HashMap<String, String>();
		for (String key : map1.keySet()) {
			String value = map1.get(key);
			map2.put(value, key);
		}
		System.out.println("Map2 :-- > " + map2);
		
		
//		----------------------------MAP 3 --------------------------
		Map<Integer, Integer> map3 = new HashMap<Integer, Integer>();
		
		for (String key : map2.keySet()) {
			int num_key = Integer.parseInt(key);
			map3.put(num_key, num_key);
		}
		System.out.println("Map3 :-- > " + map3);
		
//		-----------------------------MAP 4 -------------------------
		Map<String, String> map4 = new HashMap<String, String>();
		for (String key : map1.keySet()) {
			map4.put(key, key);
		}
		System.out.println("Map4 :-- > " + map4);
		
		
	}
}
