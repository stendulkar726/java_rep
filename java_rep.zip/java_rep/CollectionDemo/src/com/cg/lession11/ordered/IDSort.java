package com.cg.lession11.ordered;

import java.util.Comparator;


import com.cg.lession10.array.Employee;

public class IDSort implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
//		int r= 0;
//		if (e1.getId() < e2.getId())
//			r = -1;
//		else if (e1.getId() > e2.getId())
//			r= 1;
//		else
//			r=0;
//		return r;
		return (o1.getId() < o2.getId() ? -1 : (o1.getId() > o2.getId()) ? 1 : 0);
	}

}
