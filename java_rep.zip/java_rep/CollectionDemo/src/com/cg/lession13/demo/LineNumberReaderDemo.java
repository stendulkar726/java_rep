package com.cg.lession13.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class LineNumberReaderDemo {
	public static void main(String[] args) {
		String s;
		File f = new File("mydir" , "mytxt.txt");
		
		try {
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			LineNumberReader lr = new LineNumberReader(br);
			
			while ((s = lr.readLine()) != null) {
				System.out.println(lr.getLineNumber() + " " + s);
			}
		} catch (IOException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}
