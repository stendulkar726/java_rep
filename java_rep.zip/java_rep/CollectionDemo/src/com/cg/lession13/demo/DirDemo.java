package com.cg.lession13.demo;

import java.io.File;

public class DirDemo {
	public static void main(String[] args) {
		File f = new File("mydir");
		boolean flag = f.mkdir();
		if(flag) {
			System.out.println("dir created");
		}
		else {
			System.out.println("unabe to create directory");
		}
	}
}
