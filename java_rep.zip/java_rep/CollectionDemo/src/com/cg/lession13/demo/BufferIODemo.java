package com.cg.lession13.demo;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferIODemo {

	public static void main(String[] args) {
		File f = new File("mydir" , "mytxt.txt");
		try {
			FileOutputStream fos = new FileOutputStream(f);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			
			String str = "My BufferedOutputStream Example";
			bos.write(str.getBytes());
			
			System.out.println("File Written");
			
			bos.flush();
			bos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e)
		{
			e.printStackTrace();
		}

	}

}
