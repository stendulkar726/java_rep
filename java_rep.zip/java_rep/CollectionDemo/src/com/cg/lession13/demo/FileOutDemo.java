package com.cg.lession13.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutDemo {

	public static void main(String[] args) {
		String str = "This is Capgemini \n";
		File f = new File("mydir" , "mytxt.txt");
		
		
		try {
		FileOutputStream fout = new FileOutputStream(f, true);//true will not overwrite the file...false will
		byte[] b = str.getBytes();
		fout.write(b);
		fout.close();
			
		}catch(FileNotFoundException e){
			e.printStackTrace();
			
		}
		catch(IOException e) {
			e.printStackTrace();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
