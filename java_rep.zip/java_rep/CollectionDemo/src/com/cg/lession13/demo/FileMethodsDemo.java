package com.cg.lession13.demo;

import java.io.File;

public class FileMethodsDemo {

	public static void main(String[] args) {
		File f1 = new File("mydir");
		File f2 = new File("mydir" , "mytxt.txt");
		
		if (f1.isDirectory()) {
			System.out.println(f1.getName() + " is a directory");
		} else {
			System.out.println(f1.getName() + " is NOT a directory");
		}
		
		if (f2.isFile()) {
			System.out.println(f2.getName() + " is a file");
		} else {
			System.out.println(f2.getName() + " is NOT a file");
		}
		
		System.out.println("Path :> " + f1.getPath());
		System.out.println("Absolute Path :> " + f1.getAbsolutePath());
		System.out.println("Path :> " + f2.getPath());
		System.out.println("Absolute Path :> " + f2.getAbsolutePath());
		
		//rename a file
		File f3 = new File("mydir", "myfile.txt");
		f2.renameTo(f3);
		System.out.println("Absolute Path:> " + f3.getAbsolutePath());
		
		//Delete a file
		
		if(f3.delete()) {
			System.out.println(f3.getName() + " is deleted");
			
		}else {
			System.out.println(f3.getName() + " unable to delete");
		}
		

	}

}
