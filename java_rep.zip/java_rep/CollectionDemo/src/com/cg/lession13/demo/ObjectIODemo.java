package com.cg.lession13.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectIODemo {
	public static void main(String[] args) {
		File f = new File("mydir" , "mytxt.txt");
		Emp e1 = null;
		e1 = new Emp(1001 , "Abhimanyu" , 40000000.00);
		
		try {
			FileOutputStream fout = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			oos.writeObject(e1);
			oos.flush();
			oos.close();
			fout.close();
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("serialised");
		
		try {
			FileInputStream fin = new FileInputStream(f);
			ObjectInputStream ois = new ObjectInputStream(fin);
			e1 = (Emp) ois.readObject();
			System.out.println(e1);
			ois.close();
			fin.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
