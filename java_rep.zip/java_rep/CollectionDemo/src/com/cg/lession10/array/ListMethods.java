package com.cg.lession10.array;

import java.util.ArrayList;

public class ListMethods {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		System.out.println("Empty :> " + al.isEmpty());
		al.add("A");
		al.add("B");
		al.add("C");
		al.add("B");
		al.add("D");
		al.add("E");
		al.add("C");
		
		System.out.println("Size :> " + al.size());
		System.out.println("Contain A:> " + al.contains("A"));
		System.out.println("Contain a:> " + al.contains("a"));
		System.out.println("Index of C:> " + al.indexOf("C"));
		System.out.println("Last Index of C:> " + al.lastIndexOf("C"));
		
		al.add(0, "One");
		System.out.println(al);
		
		al.set(0, "first");
		System.out.println(al);
		
		al.remove("first");
		System.out.println(al);
		
		al.remove(3);
		System.out.println("After deletion:> " + al);
		
		
		

	}

}
