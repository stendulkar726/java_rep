package com.cg.lession10.array;

public class VarArgsDemo {
	 public void list(String str) {
		 System.out.println(str);
	 }
	 
	 public void list(String str1, String str2) {
		 
		System.out.println(str1 + " " + str2);
	}
	 
//	 
//	 public void list(String[] str) {
//		 
//		for (String s : str) {
//		 System.out.println(s);
//		}
//	 }
//		
		public void list(String...str) {
			 
			for (String s : str) {
			 System.out.println(s);
			}
	 
	 }
		
		
		
		public void show(int i) {
			System.out.println("primitive");
		}
		
		public void show(Integer i) {
			System.out.println("Wrapper");
		}
		
		public void show(int...i) {
			System.out.println("Var args");
		}
		public void hobbies(String name, String...hobby) {
			System.out.println("Name: > " + name);
			System.out.println("Hobbies :> ");
			for (String h : hobby) {
				System.out.println(h);
			}
		}

}
