package com.cg.lession10.array;

public class Main {

	public static void main(String[] args) {
		VarArgsDemo v = new VarArgsDemo();
		v.list("Hello");
		v.list("hello", "Abhimanyu");
		String str[] = {"one","two"};
		v.list(str);
		v.show(10);
		Integer i = 20;
		v.show(i);
		
		v.show(10,i);
		
		
		v.hobbies("Abhi");
		v.hobbies("Abhi", "Cricket");
		v.hobbies("Abhi", "Cricket", "chess");
	}

}
