package com.cg.lession10.array;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableDemo {

	public static void main(String[] args) {
		Employee e1 = new Employee(1006,"Abhimanyu",90000.00);
		Employee e2 = new Employee(1004,"Abhishek",20000.00);
		Employee e3 = new Employee(1003,"Bala",60000.00);
		Employee e4 = new Employee(1002,"Shaitan",40000.00);
		Employee e5 = new Employee(1007,"Ka",10000.00);
		Employee e6 = new Employee(1005,"Saala",30000.00);
		Employee e7 = new Employee(1001,"Bulla",80000.00);
		
		ArrayList<Employee> al = new ArrayList<Employee>();
		
		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		al.add(e5);
		al.add(e6);
		al.add(e7);
		
		System.out.println("Before Sort:--> ");
		
		for (Employee e : al) {
			System.out.println(e);
		}
		
		System.out.println("After sorting:-->");
		Collections.sort(al);
		
		for (Employee e : al) {
			System.out.println(e);
		}
		
		

	}

}
