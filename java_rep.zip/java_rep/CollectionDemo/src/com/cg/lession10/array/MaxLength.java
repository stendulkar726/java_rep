package com.cg.lession10.array;

import java.util.ArrayList;
import java.util.Scanner;

public class MaxLength {
	public static void main(String[] args) {
		ArrayList<String> nm = new ArrayList<String>();
		nm.add("Abhimanyu");
		nm.add("Himmahs");
		nm.add("Deepan");
		
		String max = "False";
		int pos = -1;
		for (String g : nm) {
			if(g.length()>pos)
			{	max = g;
				pos = g.length();
			}
		}
		System.out.println("Max = " + max + " length = " + max.length());
	}
}
