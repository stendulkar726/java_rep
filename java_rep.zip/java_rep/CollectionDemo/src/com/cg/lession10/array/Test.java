package com.cg.lession10.array;

public class Test {

	public static void main(String[] args) {
		Emp e1 = new Emp("1001", "admin", "admin");
		Emp e2 = new Emp("1002", "Abhi", "Senior dev");
		Emp e3 = new Emp("1003", "Manyu", "Junior dev");
		
		Emp[] earr = new Emp[3]; //Declare object array
		
		earr[0] = e1;
		earr[1] = e2;
		earr[2] = e3;
		
		Emp ee = earr[2];
		System.out.println(ee);
		
		for (int i = 0; i < earr.length; i++) {
			System.out.println(earr[i]);
		}
		
		for (Emp emp : earr) {
			System.out.println(emp);
		}
	}

}
