package com.cg.lession10.array;

import java.util.ArrayList;
import java.util.Iterator;


public class ArrayListDemo {
	public static void main(String[] args) {
		
		ArrayList<String> al = new ArrayList<String>();
		al.add("one");
		al.add("two");
		al.add("three");
		al.add("four");
		al.add("five");
		al.add("three");
		
		System.out.println(al);
		
		//Index base
		
		System.out.println("index base retrieve");
		String str = al.get(1);
		System.out.println(str);
		System.out.println();
		
		//iterative base retrieve
		System.out.println("Iterative base retrieve");
		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			String sst = (String) itr.next();
			System.out.println(sst);
		}
		
		//for loop iterative
		System.out.println("For loop based iterative");
		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i));
			
		}
		
		System.out.println();
		
		//for each loop iterative
		System.out.println("For each loop iterative");
		
		for (String ss : al) {
			System.out.println(ss);
		}
	
		
		System.out.println("---------------Java 8.0------------------");
		System.out.println("Iterating by passing lambda expression");
		al.forEach(ss-> System.out.println(ss));
		
		System.out.println("------------Iterating by passing method---------");
		al.forEach(System.out::println);
		
		
		
		
	}
}
