package com.cg.lession10.array;

public class PrimitiveDemo {
	public static void main(String[] args) {
		int[] arr = new int[5];
		arr[0] = 100;
		arr[1] = 200;
		arr[2] = 300;
		
		
		//retrieve by index
		int a = arr[2];
		System.out.println("a = " + a);
		
		//for loop
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		//foreach loop
		for (int i : arr) {
			System.out.println(i);
		}
	}
}
