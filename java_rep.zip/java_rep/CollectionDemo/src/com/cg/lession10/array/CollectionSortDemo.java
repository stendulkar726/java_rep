package com.cg.lession10.array;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionSortDemo {
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(10);
		al.add(3);
		al.add(5);
		al.add(-2);
		al.add(6);
		al.add(8);
		al.add(01);
		
		System.out.println("Before sorting:-- " + al);
		
		Collections.sort(al);
		
		System.out.println("After sorting:-- " + al);
		
		
		ArrayList<String> al1 = new ArrayList<String>();
		al1.add("one");
		al1.add("two");
		al1.add("three");
		al1.add("four");
		al1.add("six");
		al1.add("five");
		
		System.out.println("Before sorting:-- " + al1);
		
		Collections.sort(al1);
		
		System.out.println("After sorting:-- " + al1);
	}

}
