package com.cg.lession10.array;

import java.util.ArrayList;

public class ListMethodsDemo {
	public static void main(String[] args) {
		ArrayList<String> arr1 = new ArrayList<String>();
		arr1.add("A");
		arr1.add("B");
		arr1.add("C");
		arr1.add("D");
		
		ArrayList<String> arr2 = new ArrayList<String>();
		arr2.add("1");
		arr2.add("2");
		arr2.add("3");
		arr2.add("4");
		
		ArrayList<String> al = new ArrayList<String>();
		
		//al now contains [a,b,c]
		al.addAll(arr1);
		System.out.println(al);
		
		
		//al now contains [a,b,c,1,2,3]
		al.addAll(arr2);
		System.out.println(al);
		
		
//		al now contain [1,2,3]
		al.retainAll(arr2);
		System.out.println(al);
		
		
//		nothing happens - already removed
		boolean f = al.removeAll(arr1);
		if (f) {
			System.out.println("True");
		} else {
			System.out.println("False");
		}
		al.removeAll(arr2); //target is now empty
	}
}
