package com.cg.lession10.array;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class ArrayVsList {
	public static void main(String[] args) {
		String[] str = {"one", "two", "three"};
		
		List<String> strList = Arrays.asList(str);
		
		
		for (String st : strList) {
			System.out.println(st);
		}
		
		ArrayList<String> al =new ArrayList<String>(strList);
		al.add("Six");
		System.out.println(al);
		al.remove(4);
		System.out.println(al);
	}
}
