package com.cg.lession16.demo;

import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import oracle.jdbc.OracleSavepoint;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.driver.OracleDriver;

public class TransactionDemo {
	public static void main(String[] args) {
		String driverName="oracle.jdbc.OracleDriver";
	    String url="jdbc:oracle:thin:@localhost:1521:XE";
	    String username="ABHIMANYU1";
	    String password="ABHIMANYU1";
	    OracleConnection conn = null;
	    OracleSavepoint spoint = null;
	    
	    try {
			DriverManager.registerDriver(new OracleDriver());
			
			conn = (OracleConnection)DriverManager.getConnection(url, username, password);
			
			//Disabling auto commit 
			conn.setAutoCommit(false);
			DatabaseMetaData dbmd = conn.getMetaData();
			
			//Check whether Savepoint is supported
			if (dbmd.supportsSavepoints()) {
				System.out.println("Savepoint is supported");
				
			} else {
				System.out.println("Savepoint is not supported");
			}
			
			
//			Disabling auto commit
		    conn.setAutoCommit(false);
		    System.out.println("Before transaction.....");
		    
		    Statement stmt0 = conn.createStatement();
		    ResultSet rsl = stmt0.executeQuery("select * from login");
		    
		    while (rsl.next()) {
				System.out.println(rsl.getInt(1) + " " + rsl.getString(2) + " " + rsl.getString(3));
			}
		    
		    spoint = conn.oracleSetSavepoint();
            Statement stmt1 = conn.createStatement();
            stmt1.executeUpdate("" + "update login set uname='meena' where id=1002");
            Statement stmt2 = conn.createStatement();
            stmt2.executeUpdate("" + "update login set uname='kavita' where id=1003");
            
            System.out.println("After transaction....");
            Statement stmt3 = conn.createStatement();
            ResultSet rs2 = stmt3.executeQuery("select *from login");
            while(rs2.next()){
                System.out.println(rs2.getInt(1) + " " + rs2.getString(2));
            }
            conn.rollback();
            conn.commit();
            conn.close();
		    
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	    
	    
	    
	    
	    
	    
	    
	}

}
