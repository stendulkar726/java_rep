package com.cg.lession16.demo;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DisplayRows {

	public static void main(String[] args) {
		Connection connection = null;
		String driverName = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "ABHIMANYU1";
		String password = "ABHIMANYU1";
		
		
		//1. load jdbc driver
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		
		//2. Create a connection to db
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection established with oracle.....");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		try {
			// 3. create string query
			String query = "select *from login";
			
			//4. create a statement
			Statement st = connection.createStatement();
			
			//5. Execute query
			ResultSet rs = st.executeQuery(query);
			
			//6. Iterate rows
			while (rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4));;
			}
			
//			7. close all
			rs.close();
			st.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

}
