package com.cg.lession16.demo;

import java.util.List;


public class Main {
    public static void main(String args[]) {
        LoginDAO ldao=new LoginDAO();
        Login l = new Login(1009, "abc" , "abc" , "xyz");
        ldao.newLogin(l);
        
//        List lst=ldao.getAllRows();
//        for(Object object:lst) {
//            System.out.println(object);
//        }
    
    }
}