package com.cg.lession16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

 

public class LoginDAO {
    Connection  connection=null;
    String driverName="oracle.jdbc.OracleDriver";
    String url="jdbc:oracle:thin:@localhost:1521:XE";
    String username="ABHIMANYU1";
    String password="ABHIMANYU1";
    public Connection getConnection() {
        //load the JDBC driver        
                try {
                    Class.forName(driverName);
                } catch(ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
                //create the connection to the database
                try {
                    connection = DriverManager.getConnection(url, username, password);
                    System.out.println("connection established with oracle...");
                } catch(SQLException e) {
                    e.printStackTrace();
                }
                return connection;
    }
    public Login getLogin(int id) {
    	Login login = null;
    	connection = getConnection();
    	PreparedStatement psmt = null;
    	String str = "select * from login where id = ?";
    	try {
    		psmt = connection.prepareStatement(str);
    		psmt.setInt(1, id);
    		
    		ResultSet rs = psmt.executeQuery();
    		rs.next();
    		login = new Login(rs.getInt(1) , rs.getString(2) ,rs.getString(3) , rs.getString(4));
		} catch (SQLException e) {
			
			System.out.println(e.getErrorCode() + " ");
			System.out.println(e.getSQLState());
		}
    	
    	
    	
    	
    	
    	return login;
    	
    }

	public Login getAllRows() {
        Login list=new Login();
        connection=getConnection();
        Login login=null;
        try {
            //create query string
            String query="select * from login";
            //create a statement
            Statement st=connection.createStatement();
            //execute query
            ResultSet rs=st.executeQuery(query);
            
            
            //iterate rows
            while(rs.next()) {
                login=new Login(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
                
                }

 

        } catch(Exception e2) {
            e2.printStackTrace();
        }
        return list;
    }
    
    public void newLogin(Login login) {
    	System.out.println("insert into login values(" + login.getId() + ",'" + login.getUname() + "','" + login.getPwd()+ "','" + login.getRole() + "')");
    }
    
    
}