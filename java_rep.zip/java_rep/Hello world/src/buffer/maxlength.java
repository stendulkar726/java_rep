package buffer;

public class maxlength {
 public static void main(String[] args) {
	 String s= "hello how are you abhimanyu";
     String [] word = s.split(" ");
String maxlethWord = "";
for(int i = 0; i < word.length; i++){
      if(word[i].length() >= maxlethWord.length()){
            maxlethWord = word[i];
      } 
}
System.out.println(maxlethWord);  
}
}




