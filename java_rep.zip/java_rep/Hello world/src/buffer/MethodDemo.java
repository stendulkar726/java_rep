package buffer;

public class MethodDemo {
	public static void main(String[] args) {
		String str = "Hello";
		StringBuffer sb = new StringBuffer(str);
		System.out.println("length :>" + sb.length());
		System.out.println("capacity :> " + sb.capacity());
		
		sb.append("world!");
		
		sb.insert(5, " ");
		System.out.println(sb.toString());
		
		sb.reverse();
		System.out.println("Reverse :> " + sb.toString());
	}
}
