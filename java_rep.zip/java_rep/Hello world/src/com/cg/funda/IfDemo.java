package com.cg.funda;

public class IfDemo {
	public static void main(String[] args) {
	int age = 19;
	if(age>18) {
		System.out.println("Adult");
	}
	else {
		System.out.println("Not adult");
	}

}
}