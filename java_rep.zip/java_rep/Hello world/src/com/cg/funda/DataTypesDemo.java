package com.cg.funda;

public class DataTypesDemo {
	public static void main(String[] args)
	{
		boolean flag = true;
		System.out.println("boolean flag = " +flag);
		
		char ch = 'A';
		System.out.println("char ch = "+ ch);
		
		byte b = 12;
		System.out.println("byte b = "+ b);
		
		float f = 1.344564f;
		System.out.println("float f = "+ f);
	}

}
