package com.cg.lession9.exception;

public class Except1 {
	public static void main(String[] args) {
		int a = 10, b =3 , c=0 ;
		c = a / b;
		System.out.println(" c = " + c);
	}
}
