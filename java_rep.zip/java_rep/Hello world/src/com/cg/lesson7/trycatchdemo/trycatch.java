package com.cg.lesson7.trycatchdemo;

public class trycatch {
	public static void main(String[] args) {
		try {
			String str = "Abhimanyu";
			int l = str.length();
			try {
				int a = 10, b = 0, c=0;
				c = a/b;
				System.out.println("c = " + c);
				
			}
			
			catch (NullPointerException e){
				System.out.println("Null");
				
			}
		}
		
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Divided by zero");
		}
	}
}
