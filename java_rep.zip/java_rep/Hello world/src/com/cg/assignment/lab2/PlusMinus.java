package com.cg.assignment.lab2;

import java.util.Scanner;

public class PlusMinus {
	public static void main(String[] args) {
		Scanner num = new Scanner(System.in);
		int num2 = num.nextInt();
		if (num2<0) {
			System.out.println("Number is negative");

		} else {
			System.out.println("Number is positive");

		}
	}

}

