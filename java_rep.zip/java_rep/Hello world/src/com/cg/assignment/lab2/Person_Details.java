package com.cg.assignment.lab2;

public class Person_Details {
	public static void main(String[] args) {
		
		String name = "Divya";
		String last = "Bharathi";
		String gen = "F";
		int age = 20;
		double weight = 85.55;
		System.out.println("Person Details:");
		System.out.println("-----------------");
		System.out.println("First Name : " + name);
		System.out.println("Last Name : " + last);
		System.out.println("Gender : " + gen);
		System.out.println("Age : " + age);
		System.out.println("Weight : " + weight);
	}

}
