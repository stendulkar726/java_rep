package com.cg.lession7.interdemo;

public class MyNewClass extends AbsClass{

	@Override
	void show() {
		// TODO Auto-generated method stub
		System.out.println("MyNewClass::show()");
	}

}
