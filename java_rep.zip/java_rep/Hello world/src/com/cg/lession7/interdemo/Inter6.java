package com.cg.lession7.interdemo;

public interface Inter6 extends MyInter{

	

}
