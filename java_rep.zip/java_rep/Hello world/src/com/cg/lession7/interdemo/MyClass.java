package com.cg.lession7.interdemo;

public class MyClass implements MyInter {

	@Override
	public void show() {
		
		System.out.println("Show()");
		
	}

	@Override
	public void display() {
		System.out.println("Display()");
		
	}
	

}
