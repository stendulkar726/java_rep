package com.cg.lession7.interdemo;

public abstract class AbsClass {
	abstract void show(); //Declare Method
	
	
	public void list() //Define method 
	{
		System.out.println("AbsClass::list()");
	}
	
	

}
