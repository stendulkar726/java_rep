package com.cg.lession7.interdemo;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyNewClass m = new MyNewClass();
		m.show();
		m.list();
		

	}

}
