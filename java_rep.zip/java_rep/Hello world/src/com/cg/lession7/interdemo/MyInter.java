package com.cg.lession7.interdemo;

public interface MyInter {
	abstract void show();
	void display();
}
