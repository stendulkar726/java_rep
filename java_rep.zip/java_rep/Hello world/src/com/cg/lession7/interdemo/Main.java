package com.cg.lession7.interdemo;

public class Main {

	public static void main(String[] args) {
		MyClass m = new MyClass();
		m.show();
		m.display();

	}

}
