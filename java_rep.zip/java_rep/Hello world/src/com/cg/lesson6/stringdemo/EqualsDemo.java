package com.cg.lesson6.stringdemo;

public class EqualsDemo {
	public static void main(String[] args) {
		String s1 = "hello";
		String s2 = "hello";
		
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
		if(s1.hashCode() == s2.hashCode()) {
			System.out.println("Both object share common address/values");
			
			
		}
		else {
			System.out.println("Both object DOES NOT share common address/values");
		}
		
		
		
		
		
		
		boolean f = s1.equals(s2);
		if(f) {
			System.out.println("S1 s2 contents are equal");
		}
		
		s2 = "Hello";
		f = s1.equals(s2);
		
		if(f) {
			System.out.println("s1 s2 contents equal");
		}
		else {
//			System.out.println("s1 s2 content not equal");
		}
	}

}
