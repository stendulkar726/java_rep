package com.cg.lesson6.stringdemo;

public class GetBytesDemo {
	public static void main(String[] args) {
		String s1 = "technology";
		byte[] b  = s1.getBytes();
		for (byte c : b) {
			System.out.println(c + " " + (char)c);
		}
	}

}
