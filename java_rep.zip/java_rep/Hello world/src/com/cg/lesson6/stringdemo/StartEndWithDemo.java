package com.cg.lesson6.stringdemo;

public class StartEndWithDemo {
	public static void main(String[] args) {
		String s1 = "technology";
		boolean f1 = s1.startsWith("tech");
		
		if(f1) {
			System.out.println(s1 + " start with tech");
			
		}
		
		else
		{
			System.out.println(s1 + " Not start with tech");
		}
		
		
		
		boolean f2 = s1.endsWith("logy");
		if(f2) {
			System.out.println(s1 + " end with logy");
			
			
		}
		
		else
		{
			System.out.println(s1 + " not end with logy");
		}
		
		String email = "abc@cg.com";
		
		boolean f3 = email.endsWith("@cg.com");
		if(f3) {
			System.out.println(email + " is a capg mail");
			
			
		}
		
		else
		{
			System.out.println(email + " is not a capg mail");
		}
	}
}
