package com.cg.lesson6.stringdemo;

public class Substring {
	public static void main(String[] args) {
		String s1 = "Hindustan Computers";
		String s2 = s1.substring(5,15);
		System.out.println(s2);
		
		String s3 = "Hindustan";
		String s4 = s3.replace('n', 'a');
		System.out.println(s4);
		
	}
}
