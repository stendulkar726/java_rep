package com.cg.lesson6.datedemo;
import java.lang.invoke.LambdaConversionException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class LocalDateExample {
 public static void main(String[] args) {
	//current date
	 LocalDate today = LocalDate.now();
	 System.out.println("Current Date = " + today);
	 
	 //creating local date by providing input args
	 LocalDate firstday_2014 = LocalDate.of(2014, 01, 1);
	 System.out.println("Specific Date = " + firstday_2014);
	 
	 System.out.println(firstday_2014.getClass().getSimpleName());
	 
	 
	 LocalDateTime now = LocalDateTime.now();
	 
	 System.out.println("Now :: " + now);
	 System.out.println();
	 System.out.println("Date : " + now.getDayOfMonth());
	 System.out.println("Month : " + now.getMonth());
	 System.out.println("Year : " + now.getYear());
	 System.out.println("Month : " + now.getMonthValue());
	 System.out.println();
	 System.out.println("Hour : " + now.getHour());
	 System.out.println("Minute : " + now.getMinute());
	 System.out.println("Second : " + now.getSecond());
	 System.out.println("Nano : " + now.getNano());
	 
	 
	 
	 
	 //---------------------------Plus---Minus---Demo----------------------------------------------
	 System.out.println();
	 System.out.println(now);
	 System.out.println("10 days after: "+ now.plusDays(10));
	 System.out.println("2 weeks after: "+ now.plusWeeks(2));
	 System.out.println("10 months after: "+ now.plusMonths(10));
	 System.out.println("10 years after: "+ now.plusYears(10));
	 System.out.println();
	 System.out.println("10 days before: "+ now.minusDays(10));
	 System.out.println("2 weeks before: "+ now.minusWeeks(2));
	 System.out.println("10 months before: "+ now.minusMonths(10));
	 System.out.println("10 years before: "+ now.minusYears(10));
	 
	 
	 
	 //------------------------------------zone demo------------------------
	 
	 
	 ZonedDateTime ct = ZonedDateTime.now();
	 System.out.println(ct);
	 ZonedDateTime paris = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
	 System.out.println(paris);
	 
	 //------------------------------of--parse----demo----------------------------
	 //Uses DateTimeformatter
	 LocalDate date1 = LocalDate.of(2018, 2, 13);
	 LocalDate date2 = LocalDate.parse("2018-02-13");
	 System.out.println(date1 + " "+ date2);
	 
	 
	 LocalTime time1 = LocalTime.of(6, 30);
	 LocalTime time2 = LocalTime.parse("06:30");
	 System.out.println(time1 + " " + time2);
	 
	 
	 //------------------------------format Date demo----------------------------
	 
	 LocalDate date = LocalDate.now();
	 
	 DateTimeFormatter frmt = null;
	 frmt = DateTimeFormatter.ofPattern("dd MM yyyy"); // small m is for minute and capital is for month
	 
	 String text = date.format(frmt);
	 System.out.println(text);
	 
	 frmt = DateTimeFormatter.ofPattern("M");
	 String mon1 = date.format(frmt);
	 System.out.println("M = " + mon1);
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
}
