package com.cg.lesson4.demo;

public class Balance {
	String name;
	double bal;
	
	public Balance(String name, double bal) {
		super();
		this.name = name;
		this.bal = bal;
		
	}
	public void show() {
		if(bal<0) {
			System.out.println(name +" Rs. " +bal);
		}
	}

}
