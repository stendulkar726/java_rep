package com.cg.lession6.overload;

public class Main {
	public static void main(String[] args) {
	Sum s = new Sum();
	int r = 0;
	r = s.add(10, 20);
	System.out.println("s.add(10,20) = "+ r);
	
	r = s.add(10, 20, 30);
	System.out.println("s.add(10,20,30) = "+ r);
	
	
	double d = s.add(10.10, 20.20);
	System.out.println("s.add(10.10,20.20) = "+ d);
	
	d = s.add(10.10, 20.20, 30.30);
	System.out.println("s.add(10.10,20.20,30.30) = "+ d);
	
}
}
