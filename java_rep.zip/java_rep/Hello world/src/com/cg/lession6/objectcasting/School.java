package com.cg.lession6.objectcasting;

public class School extends Student{
	private String group;

	public School(int id2, String name2) {
		super(id2, name2);
		// TODO Auto-generated constructor stub
	}

	public School(int id2, String name2, String group) {
		super(id2, name2);
		this.group = group;
	}

	@Override
	public String toString() {
		return "School [group=" + group + "]";
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	
}
