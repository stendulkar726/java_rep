package com.cg.lession6.objectcasting;

public class Collage extends School {
	private String major;

	public Collage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Collage(int id, String name, String group) {
		super(id, name, group);
		// TODO Auto-generated constructor stub
	}

	public Collage(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Collage [major=" + major + "]";
	}
}
