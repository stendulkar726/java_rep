package com.cg.lession6.objectcasting;

public class ExplicitDemo {
public static void main(String[] args) {
	Student s = new Student(1001, "Abhi");
	System.out.println(s);
	
	School sc = (School) s;
	
	System.out.println(sc);
			
}
}
