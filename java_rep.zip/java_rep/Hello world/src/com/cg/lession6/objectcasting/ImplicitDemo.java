package com.cg.lession6.objectcasting;

public class ImplicitDemo {
 public static void main(String[] args) {
	Collage c = new Collage(1001, "abhimanyu", "1", "CS" );
	System.out.println(c);
	Student s = c;
	System.out.println(s);
	School sc  = c;
	System.out.println(sc);
}
}
