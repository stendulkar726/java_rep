package com.cg.lession6.dynamic;

public class B extends A {
	@Override
	public void show() {
		System.out.println("B::show()");
	}
}
