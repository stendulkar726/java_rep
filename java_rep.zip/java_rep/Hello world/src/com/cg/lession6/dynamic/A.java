package com.cg.lession6.dynamic;

public class A {
	
	public void show() {
	 System.out.println("A::show()");
 }
}
