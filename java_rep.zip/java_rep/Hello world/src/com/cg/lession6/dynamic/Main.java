package com.cg.lession6.dynamic;

public class Main {
 public static void main(String[] args) {
	A a = null;
	a = new A();
	a.show();
	
	a  = new B();
	a.show();
	
	a = new C();
	a.show();
}
}
