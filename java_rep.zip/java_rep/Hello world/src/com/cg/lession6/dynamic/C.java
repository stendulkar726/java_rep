package com.cg.lession6.dynamic;

public class C extends B {
	@Override
	public void show() {
		System.out.println("C::show()");
	}
	

}
