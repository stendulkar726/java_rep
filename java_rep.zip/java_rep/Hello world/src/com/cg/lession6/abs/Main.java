package com.cg.lession6.abs;

public class Main {

	public static void main(String[] args) {
		MeatEater tiger =  new MeatEater("Tiger");
		tiger.eat();
		tiger.move();
		
		HerbEater deer = new HerbEater("Deer");
		deer.eat();
		deer.move();
		
		MeatEater lion = new MeatEater("Lion");
		lion.move();
		lion.eat();
		

	}

}
