package com.cg.lession6.abs;

public class MeatEater extends Animal{
	private String meatEater;

	public MeatEater() {
		super();
		// TODO Auto-generated constructor stub
	}


	public MeatEater(String meatEater) {
		super(meatEater);
		this.meatEater = meatEater;
	}
	
	
	@Override
	public void eat() {
		System.out.println(meatEater + " eats meat");
	}
}
