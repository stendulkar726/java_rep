package com.cg.lession6.abs;

public class Animal {
	public String animal;

	public Animal() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Animal(String animal) {
		super();
		this.animal = animal;
	}
	public void eat()
	{
		System.out.println(animal + " Meat and Herb");
	}
	public void move() {
		System.out.println(animal + " move by legs");
	}
}
