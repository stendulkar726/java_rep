package com.cg.lession6.abs;

public class HerbEater extends Animal {
	private String herbEater;

	public HerbEater() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HerbEater(String herbEater) {
		super(herbEater);
		this.herbEater = herbEater;
	}
	
	@Override
	public void eat() {
		System.out.println(herbEater + " eat herb");
	}
}
