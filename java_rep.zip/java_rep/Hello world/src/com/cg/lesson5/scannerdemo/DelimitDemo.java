package com.cg.lesson5.scannerdemo;

import java.util.Scanner;

public class DelimitDemo {
	public static void main(String[] args)
	{
		String str = "1,2,3,4,5,6";
		Scanner sc = new Scanner(str).useDelimiter(",");
		
		while(sc.hasNextInt())
		{
			int i = sc.nextInt();
			System.out.println(i);
		}
		
		while(sc.hasNextDouble())
		{
			double d = sc.nextDouble();
			System.out.println(d);
		}
	}

}

